package com.example.android.reportcard;

/**
 * ReportCard stores six numeric values, all from 1 to 10 which represent the grades in the
 * following subjects: Maths, History, Chemistry, Physics, Literature & Latin
 * These values are then used to calculate the final grade which results from the average of all
 * the subjects.
 */

public class ReportCard {

    /** Grade for Maths */
    private double mMathsGrade = 0.0;

    /** Grade for the History */
    private double mHistoryGrade = 0.0;

    /** Grade for Chemistry */
    private double mChemistryGrade = 0.0;

    /** Grade for the Physics */
    private double mPhysicsGrade = 0.0;

    /** Grade for Literature */
    private double mLiteratureGrade = 0.0;

    /** Grade for the Latin*/
    private double mLatinGrade = 0.0;

    /** Final grade */
    private double mFinalGrade;

    /** String with all grades */
    private String allGrades;

    /**
     * Create a new ReportCard object.
     *
     * @param mathsGrade is the grade for Maths
     * @param historyGrade is the grade for History
     * @param chemistryGrade is the grade for Chemistry
     * @param physicsGrade is the grade for Physics
     * @param literatureGrade is the grade for Literature
     * @param latinGrade is the grade for Latin
     */

    public ReportCard(double mathsGrade, double historyGrade, double chemistryGrade, double
            physicsGrade, double literatureGrade, double latinGrade) {

        mMathsGrade = mathsGrade;
        mHistoryGrade = historyGrade;
        mChemistryGrade = chemistryGrade;
        mPhysicsGrade = physicsGrade;
        mLiteratureGrade = literatureGrade;
        mLatinGrade = latinGrade;
    }


    /** Set the grade for Maths */
    public void setmMathsGrade(double grade) {
        mMathsGrade = grade;
    }

    /** Set the grade for History */
    public void setmHistoryGrade(double grade) {
        mHistoryGrade = grade;
    }

    /** Set the grade for Chemistry */
    public void setmChemistryGrade(double grade) {
        mChemistryGrade = grade;
    }

    /** Set the grade for Physics */
    public void setmPhysicsGrade(double grade) {
        mPhysicsGrade = grade;
    }

    /** Set the grade for Literature */
    public void setmLiteratureGrade(double grade) {
        mLiteratureGrade = grade;
    }

    /** Set the grade for Latin */
    public void setmLatinGrade(double grade) {
        mLatinGrade = grade;
    }

    /** Get the grade for Maths */
    public double getmMathsGrade() {
        return mMathsGrade;
    }

    /** Get the grade for History */
    public double getmHistoryGrade() {
        return mHistoryGrade;
    }

    /** Get the grade for Chemistry */
    public double getmChemistryGrade() {
        return mChemistryGrade;
    }

    /** Get the grade for Physics */
    public double getmPhysicsGrade() {
        return mPhysicsGrade;
    }

    /** Get the grade for Literature */
    public double getmLiteratureGrade() {
        return mLiteratureGrade;
    }

    /** Get the grade for Latin */
    public double getmLatinGrade() {
        return mLatinGrade;
    }

    /** Get the final grade by calculating it */
    public double getmFinalGrade() {
        mFinalGrade = (mMathsGrade + mHistoryGrade + mChemistryGrade + mPhysicsGrade +
                mLiteratureGrade + mLatinGrade)/6.0;
        return mFinalGrade;
    }

    @Override
    public String toString() {

        allGrades = "Maths: " + mMathsGrade + "\n" + "History: " + mHistoryGrade + "\n" +
                "Chemistry: " + mChemistryGrade + "\n" + "Physics: " + mPhysicsGrade + "\n" +
                "Literature: " + mLiteratureGrade + "\n" + "Latin: " + mLatinGrade + "\n" +
                "Final Grade: " + mFinalGrade;
        return allGrades;
    }
}
